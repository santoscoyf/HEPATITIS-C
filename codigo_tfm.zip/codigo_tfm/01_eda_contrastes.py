"""
TFM - Diagnóstico de hepatitis C
Fase 1a: EDA, contrastes de hipótesis y correlaciones
Dataset: UCI HCV (Lichtinghagen), 615 pacientes.
"""
import pandas as pd, numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
import json, os

sns.set_theme(style="whitegrid", context="paper")
FIG = "/home/claude/tfm/figuras"
OUT = "/home/claude/tfm/salidas"
UP  = "/mnt/user-data/uploads/hepatitisC.csv"

df = pd.read_csv(UP, index_col=0)

# --- Limpieza / codificación ---
df["Sex"] = df["Sex"].str.strip().map({"m": "Hombre", "f": "Mujer"})
labs = ["ALB","ALP","ALT","AST","BIL","CHE","CHOL","CREA","GGT","PROT"]

# Variable objetivo binaria: sano (0 / 0s) vs enfermo (1,2,3)
def binar(c):
    return 0 if c.startswith("0") else 1
df["Enfermo"] = df["Category"].apply(binar)
df["Grupo"] = df["Enfermo"].map({0: "Sano", 1: "Enfermo"})

resultados = {}

# ---------- 1. Resumen numérico ----------
desc = df[["Age"] + labs].describe().T[["mean","std","min","25%","50%","75%","max"]]
desc.to_csv(f"{OUT}/tabla_descriptiva.csv")
resultados["n_total"] = len(df)
resultados["dist_category"] = df["Category"].value_counts().to_dict()
resultados["dist_binaria"] = df["Grupo"].value_counts().to_dict()
resultados["dist_sexo"] = df["Sex"].value_counts().to_dict()
resultados["faltantes"] = df[labs].isnull().sum().to_dict()

# Descriptiva por grupo (media ± DE)
desc_grupo = df.groupby("Grupo")[["Age"]+labs].agg(["mean","std"]).round(2)
desc_grupo.to_csv(f"{OUT}/tabla_descriptiva_por_grupo.csv")

# ---------- 2. Contrastes de hipótesis ----------
# Para cada variable continua: normalidad (Shapiro) -> t-Student o Mann-Whitney
filas = []
for v in ["Age"] + labs:
    a = df.loc[df["Enfermo"]==0, v].dropna()
    b = df.loc[df["Enfermo"]==1, v].dropna()
    # Shapiro en cada grupo
    p_norm_a = stats.shapiro(a)[1] if len(a) <= 5000 else np.nan
    p_norm_b = stats.shapiro(b)[1] if len(b) <= 5000 else np.nan
    normal = (p_norm_a > 0.05) and (p_norm_b > 0.05)
    if normal:
        stat, p = stats.ttest_ind(a, b, equal_var=False)
        test = "t-Student (Welch)"
    else:
        stat, p = stats.mannwhitneyu(a, b, alternative="two-sided")
        test = "Mann-Whitney U"
    # Tamaño del efecto (r para MWU, Cohen d para t)
    filas.append({
        "Variable": v,
        "Media_Sano": round(a.mean(),2), "DE_Sano": round(a.std(),2),
        "Media_Enfermo": round(b.mean(),2), "DE_Enfermo": round(b.std(),2),
        "Test": test, "Estadistico": round(float(stat),3),
        "p_valor": float(p), "Significativo": p < 0.05
    })
tabla_contrastes = pd.DataFrame(filas)
tabla_contrastes.to_csv(f"{OUT}/tabla_contrastes.csv", index=False)

# Chi-cuadrado: sexo vs enfermedad
cont = pd.crosstab(df["Sex"], df["Grupo"])
chi2, p_chi, dof, _ = stats.chi2_contingency(cont)
resultados["chi2_sexo"] = {"chi2": round(chi2,3), "p": float(p_chi), "dof": int(dof)}
cont.to_csv(f"{OUT}/tabla_contingencia_sexo.csv")

# ---------- 3. Correlaciones ----------
num = df[["Age"]+labs+["Enfermo"]]
pearson = num.corr(method="pearson")
spearman = num.corr(method="spearman")
pearson.to_csv(f"{OUT}/corr_pearson.csv")
spearman.to_csv(f"{OUT}/corr_spearman.csv")

# ---------- FIGURAS ----------
# Fig 1: distribución de clases
fig, ax = plt.subplots(1,2, figsize=(10,4))
df["Category"].value_counts().plot(kind="bar", ax=ax[0], color="#4C72B0")
ax[0].set_title("Distribución de categorías originales"); ax[0].set_ylabel("Frecuencia")
ax[0].tick_params(axis='x', rotation=30)
df["Grupo"].value_counts().plot(kind="bar", ax=ax[1], color=["#55A868","#C44E52"])
ax[1].set_title("Distribución binaria (objetivo)"); ax[1].set_ylabel("Frecuencia")
plt.tight_layout(); plt.savefig(f"{FIG}/fig1_distribucion_clases.png", dpi=150); plt.close()

# Fig 2: boxplots de las 10 variables de laboratorio por grupo
fig, axes = plt.subplots(2,5, figsize=(16,7))
for i, v in enumerate(labs):
    sns.boxplot(data=df, x="Grupo", y=v, ax=axes.flat[i],
                order=["Sano","Enfermo"], palette=["#55A868","#C44E52"])
    axes.flat[i].set_title(v); axes.flat[i].set_xlabel("")
plt.tight_layout(); plt.savefig(f"{FIG}/fig2_boxplots_por_grupo.png", dpi=150); plt.close()

# Fig 3: histogramas de edad por grupo
fig, ax = plt.subplots(figsize=(7,4))
for g,c in [("Sano","#55A868"),("Enfermo","#C44E52")]:
    ax.hist(df.loc[df["Grupo"]==g,"Age"], bins=20, alpha=0.6, label=g, color=c)
ax.set_xlabel("Edad (años)"); ax.set_ylabel("Frecuencia"); ax.legend(); ax.set_title("Distribución de la edad por grupo")
plt.tight_layout(); plt.savefig(f"{FIG}/fig3_edad.png", dpi=150); plt.close()

# Fig 4: heatmap correlación Pearson
fig, ax = plt.subplots(figsize=(9,7))
sns.heatmap(pearson, annot=True, fmt=".2f", cmap="coolwarm", center=0,
            annot_kws={"size":7}, ax=ax)
ax.set_title("Matriz de correlación de Pearson")
plt.tight_layout(); plt.savefig(f"{FIG}/fig4_corr_pearson.png", dpi=150); plt.close()

# Fig 5: distribución por sexo
fig, ax = plt.subplots(figsize=(6,4))
cont.plot(kind="bar", ax=ax, color=["#C44E52","#55A868"])
ax.set_title(f"Enfermedad por sexo (χ²={chi2:.2f}, p={p_chi:.3f})")
ax.set_ylabel("Frecuencia"); ax.tick_params(axis='x', rotation=0)
plt.tight_layout(); plt.savefig(f"{FIG}/fig5_sexo.png", dpi=150); plt.close()

with open(f"{OUT}/resumen_eda.json","w") as f:
    json.dump(resultados, f, indent=2, ensure_ascii=False)

print("=== RESUMEN EDA ===")
print("N =", resultados["n_total"])
print("Binaria:", resultados["dist_binaria"])
print("\n=== CONTRASTES (ordenados por p) ===")
print(tabla_contrastes.sort_values("p_valor")[["Variable","Media_Sano","Media_Enfermo","Test","p_valor","Significativo"]].to_string(index=False))
print(f"\nChi2 sexo: chi2={chi2:.3f}, p={p_chi:.4f}")
print("\nFiguras y tablas guardadas.")
