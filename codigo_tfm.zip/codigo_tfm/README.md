# TFM — Diagnóstico de hepatitis C mediante machine learning

Código del Trabajo Fin de Máster «Modelos de machine learning para el diagnóstico
de hepatitis C a partir del perfil bioquímico hepático».

## Contenido
- `01_eda_contrastes.py` — Carga y limpieza de datos, análisis exploratorio,
  contrastes de hipótesis (Mann-Whitney, ji-cuadrado) y matrices de correlación.
  Genera las figuras y tablas descriptivas.
- `02_modelos.py` — Tuberías de procesamiento, entrenamiento de seis clasificadores
  (regresión logística, KNN, árbol de decisión, Random Forest, SVM, Naive Bayes)
  con y sin SMOTE, validación cruzada estratificada 5-fold, curvas ROC, importancia
  de variables y matriz de confusión.

## Datos
Conjunto «HCV data» del repositorio UCI (Lichtinghagen, Klawonn y Hoffmann, 2020):
https://archive.ics.uci.edu/dataset/571/hcv+data
Colocar el archivo `hepatitisC.csv` en el mismo directorio que los scripts.

## Requisitos
```
pip install pandas numpy scipy scikit-learn imbalanced-learn matplotlib seaborn
```

## Ejecución
```
python 01_eda_contrastes.py
python 02_modelos.py
```

## Reproducibilidad
Todos los procesos con componente aleatoria usan semilla fija (random_state=42).
El sobremuestreo SMOTE y las transformaciones se ajustan solo sobre el conjunto de
entrenamiento en cada partición, evitando la fuga de información.
