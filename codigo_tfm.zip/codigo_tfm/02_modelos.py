"""
TFM - Diagnóstico de hepatitis C
Fase 1b: Modelos predictivos con validación cruzada estratificada.
6 clasificadores (LR, KNN, DT, RF, SVM, NB), imputación + escalado,
SMOTE aplicado SOLO en entrenamiento (dentro de cada fold, sin fuga de datos).
"""
import pandas as pd, numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
import json

from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import (accuracy_score, recall_score, precision_score,
                             f1_score, roc_auc_score, confusion_matrix, roc_curve)
from imblearn.pipeline import Pipeline as ImbPipeline
from imblearn.over_sampling import SMOTE

sns.set_theme(style="whitegrid", context="paper")
FIG = "/home/claude/tfm/figuras"; OUT = "/home/claude/tfm/salidas"

df = pd.read_csv("/mnt/user-data/uploads/hepatitisC.csv", index_col=0)
df["Sex"] = df["Sex"].str.strip().map({"m":0,"f":1})
df["Enfermo"] = df["Category"].apply(lambda c: 0 if c.startswith("0") else 1)
labs = ["ALB","ALP","ALT","AST","BIL","CHE","CHOL","CREA","GGT","PROT"]
X = df[["Age","Sex"]+labs].values
y = df["Enfermo"].values

pre = [("imp", SimpleImputer(strategy="median")), ("sc", StandardScaler())]
modelos = {
    "Regresión logística": LogisticRegression(max_iter=1000, class_weight=None),
    "KNN (k=5)": KNeighborsClassifier(n_neighbors=5),
    "Árbol de decisión": DecisionTreeClassifier(random_state=42),
    "Random Forest": RandomForestClassifier(n_estimators=300, random_state=42),
    "SVM (RBF)": SVC(probability=True, random_state=42),
    "Naive Bayes": GaussianNB(),
}

cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

def evaluar(smote):
    filas, roc_data = [], {}
    for nombre, clf in modelos.items():
        steps = list(pre)
        if smote: steps.append(("smote", SMOTE(random_state=42)))
        steps.append(("clf", clf))
        pipe = ImbPipeline(steps)
        y_pred = cross_val_predict(pipe, X, y, cv=cv, method="predict")
        y_prob = cross_val_predict(pipe, X, y, cv=cv, method="predict_proba")[:,1]
        tn, fp, fn, tp = confusion_matrix(y, y_pred).ravel()
        filas.append({
            "Modelo": nombre,
            "Accuracy": round(accuracy_score(y,y_pred),4),
            "Recall": round(recall_score(y,y_pred),4),
            "Precision": round(precision_score(y,y_pred,zero_division=0),4),
            "Especificidad": round(tn/(tn+fp),4),
            "F1": round(f1_score(y,y_pred),4),
            "AUC": round(roc_auc_score(y,y_prob),4),
        })
        roc_data[nombre] = roc_curve(y, y_prob)
    return pd.DataFrame(filas), roc_data

res_sin, roc_sin = evaluar(smote=False)
res_con, roc_con = evaluar(smote=True)
res_sin.to_csv(f"{OUT}/resultados_sin_smote.csv", index=False)
res_con.to_csv(f"{OUT}/resultados_con_smote.csv", index=False)

# ---- Curvas ROC (con SMOTE) ----
fig, ax = plt.subplots(figsize=(7,6))
for nombre,(fpr,tpr,_) in roc_con.items():
    auc = res_con.loc[res_con["Modelo"]==nombre,"AUC"].values[0]
    ax.plot(fpr,tpr,label=f"{nombre} (AUC={auc:.3f})")
ax.plot([0,1],[0,1],"--",color="grey")
ax.set_xlabel("1 - Especificidad (FPR)"); ax.set_ylabel("Sensibilidad (TPR)")
ax.set_title("Curvas ROC — modelos con SMOTE (VC 5-fold)"); ax.legend(loc="lower right", fontsize=8)
plt.tight_layout(); plt.savefig(f"{FIG}/fig6_roc.png", dpi=150); plt.close()

# ---- Comparativa de F1 y AUC ----
fig, ax = plt.subplots(1,2, figsize=(13,5))
x = np.arange(len(res_con))
for i,m in enumerate(["F1","AUC"]):
    ax[i].bar(x-0.2, res_sin[m], 0.4, label="Sin SMOTE", color="#4C72B0")
    ax[i].bar(x+0.2, res_con[m], 0.4, label="Con SMOTE", color="#C44E52")
    ax[i].set_xticks(x); ax[i].set_xticklabels(res_con["Modelo"], rotation=35, ha="right", fontsize=8)
    ax[i].set_title(m); ax[i].set_ylim(0,1); ax[i].legend()
plt.tight_layout(); plt.savefig(f"{FIG}/fig7_comparativa.png", dpi=150); plt.close()

# ---- Importancia de variables (Random Forest) ----
rf_pipe = ImbPipeline(pre+[("smote",SMOTE(random_state=42)),
                           ("clf",RandomForestClassifier(n_estimators=300,random_state=42))])
rf_pipe.fit(X,y)
imp = pd.Series(rf_pipe.named_steps["clf"].feature_importances_,
                index=["Age","Sex"]+labs).sort_values(ascending=True)
fig, ax = plt.subplots(figsize=(7,5))
imp.plot(kind="barh", ax=ax, color="#55A868")
ax.set_title("Importancia de variables (Random Forest)"); ax.set_xlabel("Importancia")
plt.tight_layout(); plt.savefig(f"{FIG}/fig8_importancia.png", dpi=150); plt.close()

# ---- Matriz de confusión del mejor modelo por AUC ----
mejor = res_con.sort_values("AUC", ascending=False).iloc[0]["Modelo"]
steps = list(pre)+[("smote",SMOTE(random_state=42)),("clf",modelos[mejor])]
pipe = ImbPipeline(steps)
y_pred = cross_val_predict(pipe, X, y, cv=cv)
cm = confusion_matrix(y, y_pred)
fig, ax = plt.subplots(figsize=(5,4))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
            xticklabels=["Sano","Enfermo"], yticklabels=["Sano","Enfermo"], ax=ax)
ax.set_xlabel("Predicho"); ax.set_ylabel("Real"); ax.set_title(f"Matriz de confusión — {mejor}")
plt.tight_layout(); plt.savefig(f"{FIG}/fig9_confusion.png", dpi=150); plt.close()

print("=== SIN SMOTE ==="); print(res_sin.to_string(index=False))
print("\n=== CON SMOTE ==="); print(res_con.to_string(index=False))
print(f"\nMejor modelo por AUC: {mejor}")
print("\nImportancia de variables (top):")
print(imp.sort_values(ascending=False).round(3).to_string())

json.dump({"mejor_modelo": mejor,
           "sin_smote": res_sin.to_dict("records"),
           "con_smote": res_con.to_dict("records"),
           "importancia": imp.sort_values(ascending=False).round(4).to_dict()},
          open(f"{OUT}/resumen_modelos.json","w"), indent=2, ensure_ascii=False)
